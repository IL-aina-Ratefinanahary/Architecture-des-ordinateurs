Allo!

j'ai debuté mon programme avec le fichier Test Multiplication.

Merci :)